# Urban Refrigeration Website

Static HTML website inspired by the structure of the Wix HVAC Technician demo, rebuilt from scratch for Urban Refrigeration.

## GitHub Pages
1. Create a GitHub repository (for example `urban-refrigeration`).
2. Upload `index.html`.
3. Open Settings → Pages.
4. Under Build and deployment choose **Deploy from a branch**.
5. Select `main` and `/root`, then Save.
6. GitHub will provide the public website URL.

The site uses image URLs hosted by Unsplash, so no image files are required for the first version. Replace those URLs with your own photos later for a fully owned photo set.

## Contact
Phone/WhatsApp: +91 8920493413
Service area: Jamia Nagar / Okhla, Delhi
